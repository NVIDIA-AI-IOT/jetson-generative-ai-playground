"use strict";

module.exports = {
    globals: {
        JSZip: false,
        JSZipUtils: false,
        JSZipTestUtils: false,
        QUnit: false,
    },
};
